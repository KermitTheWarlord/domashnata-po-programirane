﻿using System;

namespace ConsoleApp2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Tova e vtora zadacha gospojo da znaete ne sum pisal na bulgarski zashtoto nqmam plugin za drugi ezici");
            Console.WriteLine("Enter value: ");
            int x = Convert.ToInt32(Console.ReadLine());
            int a = 0;
            int b = 1;
            int c = 2;
            int d = 3;
            int e = 4;
            int f = 5;

            if (x == a)
            {
                Console.WriteLine("Value equals to A");
            }

            else if (x == b)
            {
                Console.WriteLine("Value equals to B");
            }

            else if (x == c)
            {
                Console.WriteLine("Value equals to C");
            }

            else if (x == d)
            {
                Console.WriteLine("Value equals to D");
            }

            else if (x == e)
            {
                Console.WriteLine("Value equals to E");
            }

            else if (x == f)
            {
                Console.WriteLine("Value equals to F");
            }

            else if (x == f + e)
            {
                Console.WriteLine("Value equals to F+E");
            }

            else if (x == f + f)
            {
                Console.WriteLine("Value equals to f+f");
            }

            else if (x == f + d)
            {
                Console.WriteLine("Value equals to F+D");
            }

            else if (x == f + c)
            {
                Console.WriteLine("Value equals to F+C");
            }

            else if (x == f + b)
            {
                Console.WriteLine("Value equals to F+B");
            }

            else if (x == f + a)
            {
                Console.WriteLine("Value equals to F+A");
            }

            else if (x == e + a)
            {
                Console.WriteLine("Value equals to E+A");
            }

            else if (x == e + b)
            {
                Console.WriteLine("Value equals to E+B");
            }

            else if (x == e + c)
            {
                Console.WriteLine("Value equals to E+C");
            }

            else if (x == e + d)
            {
                Console.WriteLine("Value equals to E+D");
            }

            else if (x == e + e)
            {
                Console.WriteLine("Value equals to E+E");
            }

            else if (x == d + a)
            {
                Console.WriteLine("Value equals to D+A");
            }

            else if (x == d + b)
            {
                Console.WriteLine("Value equals to D+B");
            }

            else if (x == d + c)
            {
                Console.WriteLine("Value equals to D+C");
            }

            else if (x == d + d)
            {
                Console.WriteLine("Value equals to D+D");
            }

            else if (x == d + e)
            {
                Console.WriteLine("Value equals to D+E");
            }

            else if (x == d + f)
            {
                Console.WriteLine("Value equals to D+F");
            }

            else if (x == c + a)
            {
                Console.WriteLine("Value equals to C+A");
            }

            else if (x == c + b)
            {
                Console.WriteLine("Value equals to C+B");
            }

            else if (x == c + c)
            {
                Console.WriteLine("Value equals to C+C");
            }

            else if (x == c + d)
            {
                Console.WriteLine("Value equals to C+D");
            }

            else if (x == c + e)
            {
                Console.WriteLine("Value equals to C+E");
            }

            else if (x == c + f)
            {
                Console.WriteLine("Value equals to C+F");
            }

            else if (x == b + f)
            {
                Console.WriteLine("Value equals to B+F");
            }

            else if (x == b + e)
            {
                Console.WriteLine("Value equals to B+E");
            }

            else if (x == b + d)
            {
                Console.WriteLine("Value equals to B+D");
            }

            else if (x == b + c)
            {
                Console.WriteLine("Value equals to B+C");
            }

            else if (x == b + b)
            {
                Console.WriteLine("Value equals to B+B");
            }


            else if (x == a + f)
            {
                Console.WriteLine("Value equals to A+F");
            }

            else if (x == a + e)
            {
                Console.WriteLine("Value equals to A+E");
            }

            else if (x == a + d)
            {
                Console.WriteLine("Value equals to A+D");
            }

            else if (x == a + c)
            {
                Console.WriteLine("Value equals to A+C");
            }

            else if (x == a + b)
            {
                Console.WriteLine("Value equals to A+B");
            }

            else if (x == a + a)
            {
                Console.WriteLine("Value equals to A+A");
            }
            else
            {
                Console.WriteLine("Value does not equal to any of the numbers listed");
            }

        }
    }
}
